﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AppTrivial
{
    public partial class MainPage : ContentPage
    {

        int indexCard = 0;
        ObservableCollection<Card> cards= new ObservableCollection<Card>();
        public MainPage()
        {
            InitializeComponent();
            getCards();
        }

        private async void getCards()
        {
            var data = await GetRequest("https://opentdb.com/api.php?amount=10");
            foreach(var item in data.results)
            {
                Card mycard = new Card(item);
                this.cards.Add(mycard);
            }
            this.updateCard();
        }

        private void updateCard()
        {
            label_question.Text = System.Net.WebUtility.HtmlDecode(cards[indexCard].question);
            while(myCard.Children.Count > 1)
            {
                myCard.Children.RemoveAt(1);
            }
            foreach (string answer in cards[indexCard].answers)
            {
                Button button = new Button { Text = answer, BackgroundColor = Color.FromRgb(72, 138, 255), TextColor = Color.White };
                button.Clicked += OnButtonClicked;
                myCard.Children.Add(button);

            }

        }

        private void OnButtonClicked(object sender, EventArgs e)
        {
            button_next.IsVisible = true;
            for(int index = 1; index < myCard.Children.Count;index++)
            {
                Button myButton = ((Button)myCard.Children[index]);
                myButton.IsEnabled = false;
                myButton.BackgroundColor = Color.FromRgb(100,100,100);
                myButton.TextColor = Color.White;
                if (myButton.Text == cards[indexCard].correct_answer)
                {
                    myButton.BackgroundColor = Color.Green;
                    myButton.TextColor = Color.White;
                }
            }
            if (((Button)sender).Text != this.cards[indexCard].correct_answer)
            {
                ((Button)sender).BackgroundColor = Color.Red;
                ((Button)sender).TextColor = Color.White;
            }
        }

        private async Task<dynamic> GetRequest(string url)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(new Uri(url));
            request.ContentType = "application/json";
            request.Method = "GET";
            dynamic data = null;
            using (HttpWebResponse response = await request.GetResponseAsync() as HttpWebResponse)
            {
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    var content = reader.ReadToEnd();
                    if (!string.IsNullOrWhiteSpace(content))
                    {
                        Console.Out.WriteLine("Response Body: \r\n {0}", content);
                        data = Newtonsoft.Json.JsonConvert.DeserializeObject(content);
                        return data;
                    }
                    else
                    {
                        return null;
                    }
                }
            }
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            this.indexCard += 1;
            this.updateCard();
            button_next.IsVisible = false;
        }
    }
}
